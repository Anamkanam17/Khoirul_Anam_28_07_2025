document.getElementById("loginForm").addEventListener('submit', function(event) {
        event.preventDefault(); // Mencegah form untuk submi
        var username = document.getElementById('username').value;
        var password = document.getElementById('password').value;
        var errorMessage = document.getElementById('error-message');
        
        //validasi
        if(username === ''|| password === '') {
            errorMessage.textContent = 'gaboleh kosong woy!!';
        } else if (username !== 'anam' || password !== 'anam123') {
            errorMessage.textContent = 'username atau password salah bro';
        } else {
            errorMessage.textContent = ''
            alert('sukses login!!');
        }
            
        });